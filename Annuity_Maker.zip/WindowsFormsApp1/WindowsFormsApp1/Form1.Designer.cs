﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.yearbirth = new System.Windows.Forms.TextBox();
            this.monthbirth = new System.Windows.Forms.TextBox();
            this.daybirth = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.lastname = new System.Windows.Forms.TextBox();
            this.firstname = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.contractnumber = new System.Windows.Forms.TextBox();
            this.companylist = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.Submit = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.contractvalue = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.rider = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.rate = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.premium = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.accountype = new System.Windows.Forms.ListBox();
            this.accountnumber = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.yearbirth);
            this.groupBox1.Controls.Add(this.monthbirth);
            this.groupBox1.Controls.Add(this.daybirth);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.lastname);
            this.groupBox1.Controls.Add(this.firstname);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(200, 212);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Name";
            // 
            // yearbirth
            // 
            this.yearbirth.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.yearbirth.Location = new System.Drawing.Point(99, 106);
            this.yearbirth.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.yearbirth.Name = "yearbirth";
            this.yearbirth.Size = new System.Drawing.Size(48, 22);
            this.yearbirth.TabIndex = 6;
            this.yearbirth.Text = "1965";
            // 
            // monthbirth
            // 
            this.monthbirth.Location = new System.Drawing.Point(27, 106);
            this.monthbirth.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.monthbirth.Name = "monthbirth";
            this.monthbirth.Size = new System.Drawing.Size(29, 22);
            this.monthbirth.TabIndex = 5;
            this.monthbirth.Text = "06";
            // 
            // daybirth
            // 
            this.daybirth.Location = new System.Drawing.Point(63, 106);
            this.daybirth.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.daybirth.Name = "daybirth";
            this.daybirth.Size = new System.Drawing.Size(29, 22);
            this.daybirth.TabIndex = 4;
            this.daybirth.Text = "10";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(47, 87);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 17);
            this.label7.TabIndex = 4;
            this.label7.Text = "Date of Birth";
            // 
            // lastname
            // 
            this.lastname.Location = new System.Drawing.Point(5, 62);
            this.lastname.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.lastname.Name = "lastname";
            this.lastname.Size = new System.Drawing.Size(188, 22);
            this.lastname.TabIndex = 3;
            this.lastname.Text = "Ivashenko";
            // 
            // firstname
            // 
            this.firstname.Location = new System.Drawing.Point(5, 21);
            this.firstname.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.firstname.Name = "firstname";
            this.firstname.Size = new System.Drawing.Size(188, 22);
            this.firstname.TabIndex = 2;
            this.firstname.Text = "David";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.contractnumber);
            this.groupBox2.Controls.Add(this.companylist);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.radioButton2);
            this.groupBox2.Controls.Add(this.radioButton1);
            this.groupBox2.Location = new System.Drawing.Point(219, 12);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(232, 212);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Rider Information";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(7, 161);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(115, 17);
            this.label10.TabIndex = 12;
            this.label10.Text = "Contract Number";
            // 
            // contractnumber
            // 
            this.contractnumber.Location = new System.Drawing.Point(7, 181);
            this.contractnumber.Margin = new System.Windows.Forms.Padding(4);
            this.contractnumber.Name = "contractnumber";
            this.contractnumber.Size = new System.Drawing.Size(224, 22);
            this.contractnumber.TabIndex = 11;
            this.contractnumber.Text = "234543";
            // 
            // companylist
            // 
            this.companylist.FormattingEnabled = true;
            this.companylist.ItemHeight = 16;
            this.companylist.Items.AddRange(new object[] {
            "NSLC",
            "Ohio",
            "Metlife",
            "ING",
            "Jackson"});
            this.companylist.Location = new System.Drawing.Point(11, 64);
            this.companylist.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.companylist.Name = "companylist";
            this.companylist.Size = new System.Drawing.Size(216, 84);
            this.companylist.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(85, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(137, 17);
            this.label5.TabIndex = 0;
            this.label5.Text = "(Compound Interest)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(85, 25);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 17);
            this.label4.TabIndex = 0;
            this.label4.Text = "(Simple Interest)";
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(11, 41);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(70, 21);
            this.radioButton2.TabIndex = 0;
            this.radioButton2.Text = "GWLB";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(11, 21);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(63, 21);
            this.radioButton1.TabIndex = 0;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "GMIB";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // Submit
            // 
            this.Submit.Location = new System.Drawing.Point(501, 368);
            this.Submit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Submit.Name = "Submit";
            this.Submit.Size = new System.Drawing.Size(123, 42);
            this.Submit.TabIndex = 4;
            this.Submit.Text = "Complete";
            this.Submit.UseVisualStyleBackColor = true;
            this.Submit.Click += new System.EventHandler(this.Submit_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.contractvalue);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.rider);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Controls.Add(this.label3);
            this.groupBox3.Controls.Add(this.rate);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.premium);
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Location = new System.Drawing.Point(19, 229);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox3.Size = new System.Drawing.Size(427, 181);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Interest Info";
            // 
            // contractvalue
            // 
            this.contractvalue.Location = new System.Drawing.Point(111, 145);
            this.contractvalue.Margin = new System.Windows.Forms.Padding(4);
            this.contractvalue.Name = "contractvalue";
            this.contractvalue.Size = new System.Drawing.Size(283, 22);
            this.contractvalue.TabIndex = 12;
            this.contractvalue.Text = "200000";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(5, 149);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(101, 17);
            this.label11.TabIndex = 11;
            this.label11.Text = "Contract Value";
            // 
            // rider
            // 
            this.rider.Location = new System.Drawing.Point(111, 57);
            this.rider.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rider.Name = "rider";
            this.rider.Size = new System.Drawing.Size(283, 22);
            this.rider.TabIndex = 8;
            this.rider.Text = "300000";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(5, 59);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 17);
            this.label9.TabIndex = 10;
            this.label9.Text = "Current Rider";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(147, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "%";
            // 
            // rate
            // 
            this.rate.Location = new System.Drawing.Point(111, 87);
            this.rate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rate.Name = "rate";
            this.rate.Size = new System.Drawing.Size(29, 22);
            this.rate.TabIndex = 9;
            this.rate.Text = "8";
            this.rate.TextChanged += new System.EventHandler(this.rate_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "Interest Rate";
            // 
            // premium
            // 
            this.premium.Location = new System.Drawing.Point(111, 30);
            this.premium.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.premium.Name = "premium";
            this.premium.Size = new System.Drawing.Size(283, 22);
            this.premium.TabIndex = 7;
            this.premium.Text = "100000";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Initial Premium";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(501, 321);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(123, 42);
            this.button1.TabIndex = 6;
            this.button1.Text = "Add Annuity";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.accountype);
            this.groupBox4.Controls.Add(this.accountnumber);
            this.groupBox4.Location = new System.Drawing.Point(456, 16);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox4.Size = new System.Drawing.Size(117, 208);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Banking Info";
            // 
            // accountype
            // 
            this.accountype.FormattingEnabled = true;
            this.accountype.ItemHeight = 16;
            this.accountype.Items.AddRange(new object[] {
            "Traditional IRA",
            "Roth IRA",
            "Rollover IRA",
            "401k",
            "Non-Qualified"});
            this.accountype.Location = new System.Drawing.Point(3, 46);
            this.accountype.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.accountype.Name = "accountype";
            this.accountype.Size = new System.Drawing.Size(109, 84);
            this.accountype.TabIndex = 12;
            // 
            // accountnumber
            // 
            this.accountnumber.Location = new System.Drawing.Point(3, 18);
            this.accountnumber.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.accountnumber.Name = "accountnumber";
            this.accountnumber.Size = new System.Drawing.Size(109, 22);
            this.accountnumber.TabIndex = 11;
            this.accountnumber.Text = "5467890";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(636, 442);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.Submit);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox lastname;
        private System.Windows.Forms.TextBox firstname;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Button Submit;
        private System.Windows.Forms.TextBox daybirth;
        private System.Windows.Forms.TextBox monthbirth;
        private System.Windows.Forms.TextBox yearbirth;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox rider;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox rate;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox premium;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.ListBox accountype;
        private System.Windows.Forms.TextBox accountnumber;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox contractnumber;
        private System.Windows.Forms.TextBox contractvalue;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ListBox companylist;
    }
}

